/**
  * This file is part of the KDE project
  * Copyright (C) 2007 Rafael Fernández López <ereslibre@gmail.com>
  *
  * This library is free software; you can redistribute it and/or
  * modify it under the terms of the GNU Library General Public
  * License as published by the Free Software Foundation; either
  * version 2 of the License, or (at your option) any later version.
  *
  * This library is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  * Library General Public License for more details.
  *
  * You should have received a copy of the GNU Library General Public License
  * along with this library; see the file COPYING.LIB.  If not, write to
  * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  * Boston, MA 02110-1301, USA.
  */

#include "klistview.h"
#include "klistview_p.h"

#include <math.h> // trunc

#include <QApplication>
#include <QPainter>
#include <QScrollBar>
#include <QPaintEvent>

#include <kdebug.h>
#include <kstyle.h>

#include "kitemcategorizer.h"
#include "ksortfilterproxymodel.h"

class LessThan
{
public:
    enum Purpose
    {
        GeneralPurpose = 0,
        CategoryPurpose
    };

    inline LessThan(const KSortFilterProxyModel *proxyModel,
                    Purpose purpose)
        : proxyModel(proxyModel)
        , purpose(purpose)
    {
    }

    inline bool operator()(const QModelIndex &left,
                           const QModelIndex &right) const
    {
        if (purpose == GeneralPurpose)
        {
            return proxyModel->lessThanGeneralPurpose(left, right);
        }

        return proxyModel->lessThanCategoryPurpose(left, right);
    }

private:
    const KSortFilterProxyModel *proxyModel;
    const Purpose purpose;
};


//==============================================================================


KListView::Private::Private(KListView *listView)
    : listView(listView)
    , itemCategorizer(0)
    , proxyModel(0)
{
}

KListView::Private::~Private()
{
}

const QModelIndexList &KListView::Private::intersectionSet(const QRect &rect)
{
}

QRect KListView::Private::visualRectInViewport(const QModelIndex &index) const
{
    return QRect();
}

QRect KListView::Private::visualCategoryRectInViewport(const QString &category)
                                                                           const
{
    return QRect();
}

// We're sure elementsPosition doesn't contain index
const QRect &KListView::Private::cacheIndex(const QModelIndex &index)
{
    QRect rect = visualRectInViewport(index);
    elementsPosition.insert(index, rect);

    return elementsPosition[index];
}

// We're sure categoriesPosition doesn't contain category
const QRect &KListView::Private::cacheCategory(const QString &category)
{
    QRect rect = visualCategoryRectInViewport(category);
    categoriesPosition.insert(category, rect);

    return categoriesPosition[category];
}

const QRect &KListView::Private::cachedRectIndex(const QModelIndex &index)
{
    if (elementsPosition.contains(index)) // If we have it cached
    {                                     // return it
        return elementsPosition[index];
    }
    else
    {
        return cacheIndex(index);         // Otherwise, cache it and return it
    }
}

const QRect &KListView::Private::cachedRectCategory(const QString &category)
{
    if (categoriesPosition.contains(category)) // If we have it cached
    {                                          // return it
        return categoriesPosition[category];
    }
    else
    {
        return cacheCategory(category);        // Otherwise, cache it and
    }                                          // return it
}

QRect KListView::Private::visualRect(const QModelIndex &index)
{
    QRect retRect = cachedRectIndex(index);
    int dx = -listView->horizontalOffset();
    int dy = -listView->verticalOffset();
    retRect.adjust(dx, dy, dx, dy);

    return retRect;
}

QRect KListView::Private::categoryVisualRect(const QString &category)
{
    QRect retRect = cachedRectCategory(category);
    int dx = -listView->horizontalOffset();
    int dy = -listView->verticalOffset();
    retRect.adjust(dx, dy, dx, dy);

    return retRect;
}


//==============================================================================


KListView::KListView(QWidget *parent)
    : QListView(parent)
    , d(new Private(this))
{
}

KListView::~KListView()
{
    delete d;
}

void KListView::setModel(QAbstractItemModel *model)
{
    QListView::setModel(model);

    d->proxyModel = dynamic_cast<KSortFilterProxyModel*>(model);
}

QRect KListView::visualRect(const QModelIndex &index) const
{
    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        return QListView::visualRect(index);
    }

    return QListView::visualRect(index); 
}

KItemCategorizer *KListView::itemCategorizer() const
{
    return d->itemCategorizer;
}

void KListView::setItemCategorizer(KItemCategorizer *itemCategorizer)
{
    d->itemCategorizer = itemCategorizer;
}

QModelIndex KListView::indexAt(const QPoint &point) const
{
    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        return QListView::indexAt(point);
    }

    return QListView::indexAt(point);
}

void KListView::reset()
{
    QListView::reset();

    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        return;
    }
}

void KListView::drawNewCategory(const QString &category,
                                const QStyleOption &option,
                                QPainter *painter)
{
}

void KListView::paintEvent(QPaintEvent *event)
{
    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        QListView::paintEvent(event);
        return;
    }

    QListView::paintEvent(event);
}

void KListView::resizeEvent(QResizeEvent *event)
{
    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        QListView::resizeEvent(event);
        return;
    }

    QListView::resizeEvent(event);
}

void KListView::setSelection(const QRect &rect,
                             QItemSelectionModel::SelectionFlags flags)
{
    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        QListView::setSelection(rect, flags);
        return;
    }

    QListView::setSelection(rect, flags);
}

void KListView::mouseMoveEvent(QMouseEvent *event)
{
    QListView::mouseMoveEvent(event);

    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        return;
    }
}

void KListView::mousePressEvent(QMouseEvent *event)
{
    QListView::mousePressEvent(event);

    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        return;
    }
}

void KListView::mouseReleaseEvent(QMouseEvent *event)
{
    QListView::mouseReleaseEvent(event);

    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        return;
    }
}

void KListView::leaveEvent(QEvent *event)
{
    QListView::leaveEvent(event);

    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        return;
    }
}

void KListView::rowsInserted(const QModelIndex &parent,
                             int start,
                             int end)
{
    QListView::rowsInserted(parent, start, end);

    if ((viewMode() == KListView::ListMode) || !d->proxyModel ||
        !d->itemCategorizer)
    {
        return;
    }

    if (d->itemCategorizer)
    {
        rowsInsertedArtifficial(parent, start, end);
    }
}

void KListView::rowsRemoved(const QModelIndex &parent,
                            int start,
                            int end)
{
}

void KListView::rowsAboutToBeRemoved(const QModelIndex &parent,
                                     int start,
                                     int end)
{
    if ((viewMode() != KListView::ListMode) && d->proxyModel &&
        d->itemCategorizer)
    {
        rowsAboutToBeRemovedArtifficial(parent, start, end);
    }

    QListView::rowsAboutToBeRemoved(parent, start, end);
}
#include <kdirmodel.h>
void KListView::rowsInsertedArtifficial(const QModelIndex &parent,
                                        int start,
                                        int end)
{
    d->indexesPerCategory.clear();
    d->categories.clear();
    d->sourceModelIndexList.clear();

    for (int i = start; i <= end; i++)
    {
        d->sourceModelIndexList <<
                         d->proxyModel->mapToSource(d->proxyModel->index(i, 0));
    }

    LessThan generalLessThan(d->proxyModel,
                             LessThan::GeneralPurpose);

    qStableSort(d->sourceModelIndexList.begin(), d->sourceModelIndexList.end(),
                generalLessThan);

    QString prevCategory =
                 d->itemCategorizer->categoryForItem(d->sourceModelIndexList[0],
                                                     d->proxyModel->sortRole());
    QString lastCategory = prevCategory;
    QModelIndexList modelIndexList;
    foreach (const QModelIndex &index, d->sourceModelIndexList)
    {
        lastCategory = d->itemCategorizer->categoryForItem(index,
                                                     d->proxyModel->sortRole());

        if (prevCategory != lastCategory)
        {
            d->indexesPerCategory.insert(prevCategory, modelIndexList);
            d->categories << prevCategory;
            modelIndexList.clear();
        }

        modelIndexList << index;

        prevCategory = lastCategory;
    }

    LessThan categoryLessThan(d->proxyModel,
                              LessThan::CategoryPurpose);

    foreach (const QString &key, d->categories)
    {
        QModelIndexList &indexList = d->indexesPerCategory[key];

        qStableSort(indexList.begin(), indexList.end(), categoryLessThan);

        const KDirModel* dirModel = static_cast<const KDirModel*>(d->proxyModel->sourceModel());
        kDebug() << "WE ARE IN KEY " << key << " WITH ITEMS:" << endl;
        foreach (const QModelIndex &index, d->indexesPerCategory[key])
        {
            kDebug() << dirModel->data(index, d->proxyModel->sortRole()).toString() << endl;
        }
    }
}

void KListView::rowsAboutToBeRemovedArtifficial(const QModelIndex &parent,
                                                int start,
                                                int end)
{
}

void KListView::itemsLayoutChanged()
{
}

#include "klistview.moc"
