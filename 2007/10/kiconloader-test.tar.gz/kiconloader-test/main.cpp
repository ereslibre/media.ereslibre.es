/***************************************************************************
 *   Copyright (C) 2007 by Rafael Fernández López <ereslibre@kde.org>      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA            *
 ***************************************************************************/

/**
  * This program is meant to test KIconLoader behavior along with the Qt SVG
  * renderer state.
  */

#include <QString>
#include <KApplication>
#include <KAboutData>
#include <KMessageBox>
#include <KCmdLineArgs>
#include <KLocalizedString>
#include <kiconloader.h>
#include <QWidget>
#include <QPaintEvent>
#include <QPainter>

K_GLOBAL_STATIC(QString, string);

class MiWidget
    : public QWidget
{
protected:
    virtual void paintEvent(QPaintEvent *event)
    {
        QPainter p(this);

        p.drawPixmap(event->rect().width() / 2 - qMin(event->rect().height(), event->rect().width()) / 2,
                     event->rect().height() / 2 - qMin(event->rect().height(), event->rect().width()) / 2,
                     KIconLoader::global()->loadIcon(*string, KIconLoader::NoGroup, qMin(event->rect().height(), event->rect().width())));

        p.end();
    }
};

int main (int argc, char *argv[])
{
    KAboutData aboutData("kiconloadertest",
                         0,
                         ki18n("KIconLoader test"),
                         "1.0",
                         ki18n("KIconLoader test"),
                         KAboutData::License_GPL,
                         ki18n("(c) 2007"),
                         ki18n("Some text..."),
                         "http://www.ereslibre.es",
                         "ereslibre@kde.org");

    KCmdLineArgs::init( argc, argv, &aboutData, KCmdLineArgs::CmdLineArgNone );

    KCmdLineOptions options;
    options.add("+imageToDisplay", ki18n("A required argument 'imageToDisplay': A name of an icon (with no path) (for example: \"start-here\")"));
    KCmdLineArgs::addCmdLineOptions( options );

    KApplication app;

    KCmdLineArgs *args = KCmdLineArgs::parsedArgs();
    if (!args->count()) KCmdLineArgs::usage(i18n("A required argument 'imageToDisplay': A name of an icon (with no path) (for example: \"start-here\")").toLatin1());

    *string = args->arg(0);

    args->clear();

    MiWidget *widget = new MiWidget();
    widget->show();

    return app.exec();
}
