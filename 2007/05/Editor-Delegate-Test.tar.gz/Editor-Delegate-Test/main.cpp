/**
  * Test written by Rafael Fernández López (ereslibre)
  *
  * ereslibre@gmail.com
  */

#include <QApplication>
#include <QListView>
#include <QAbstractItemModel>
#include <QAbstractItemDelegate>
#include <QBoxLayout>
#include <QModelIndex>
#include <QList>
#include <QString>
#include <QVariant>
#include <QPushButton>
#include <QPainter>
#include <QTimer>

struct dataModel
{
    QString text;
    int number;
};

class MyModel
    : public QAbstractItemModel
{
    Q_OBJECT

public:
    MyModel(QObject *parent = 0)
        : QAbstractItemModel(parent)
    {
    }

    ~MyModel()
    {
    }

    int columnCount(const QModelIndex &index) const
    {
        Q_UNUSED(index);

        return 1;
    }

    Qt::ItemFlags flags(const QModelIndex &index) const
    {
        Q_UNUSED(index);

        return Qt::ItemIsSelectable
             | Qt::ItemIsEnabled
             | Qt::ItemIsEditable;
    }

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const
    {
        Q_UNUSED(role);

        QVariant retVar;

        switch (role)
        {
            case Qt::DisplayRole:
                retVar = dataModelList[index.row()].text;
                break;

            case Qt::DecorationRole:
                retVar = dataModelList[index.row()].number;
                break;
        }

        return retVar;
    }

    QModelIndex index(int row, int column, const QModelIndex &parent = QModelIndex()) const
    {
        Q_UNUSED(parent);

        if (row >= rowCount())
            return QModelIndex();

        return createIndex(row, column);
    }

    QModelIndex parent(const QModelIndex &index) const
    {
        Q_UNUSED(index);

        return QModelIndex();
    }

    int rowCount(const QModelIndex &parent = QModelIndex()) const
    {
        Q_UNUSED(parent);

        return dataModelList.count();
    }

    bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole)
    {
        Q_UNUSED(role);

        if (!index.isValid() || index.row() >= rowCount())
            return false;

        switch (role)
        {
            case Qt::DisplayRole:
                dataModelList[index.row()].text = value.toString();
                break;

            case Qt::DecorationRole:
                dataModelList[index.row()].number = value.toInt();
                break;
        }

        emit dataChanged(index, index);

        return true;
    }

    bool insertRows(int row, int count, const QModelIndex &parent = QModelIndex())
    {
        Q_UNUSED(row);
        Q_UNUSED(parent);

        if (count > 1)
            return false;

        beginInsertRows(QModelIndex(), row, row);

        dataModel newDataModel;

        newDataModel.text = QString();
        newDataModel.number = 0;

        dataModelList.append(newDataModel);

        endInsertRows();

        return true;
    }

    bool removeRows(int row, int count, const QModelIndex &parent = QModelIndex())
    {
        Q_UNUSED(parent);

        if (count > 1)
            return false;

        beginRemoveRows(QModelIndex(), row, row);

        dataModelList.removeAt(row);

        endRemoveRows();

        return true;
    }

public Q_SLOTS:
    void updateTime()
    {
        for (int i = 0; i < rowCount(); i++)
        {
            setData(index(i, 0), data(index(i, 0), Qt::DecorationRole).toInt() + 1, Qt::DecorationRole);
        }
    }

private:
    QList<dataModel> dataModelList;
};

class MyDelegate
    : public QAbstractItemDelegate
{
public:
    MyDelegate(QObject *parent = 0)
        : QAbstractItemDelegate(parent)
    {
    }

    ~MyDelegate()
    {
    }

    QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
    {
        Q_UNUSED(option);

        return new QPushButton(index.model()->data(index).toString(), parent);
    }

    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
    {
        if (option.state & QStyle::State_Selected)
            painter->fillRect(option.rect, option.palette.highlight());

        int numberModel = index.model()->data(index, Qt::DecorationRole).toInt();

        QRect appNameRect(20, 20 + option.rect.top(), option.fontMetrics.width(QString::number(numberModel)), option.fontMetrics.height());

        painter->drawText(appNameRect, Qt::AlignLeft, QString::number(numberModel));
    }

    QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const
    {
        Q_UNUSED(option);
        Q_UNUSED(index);

        return QSize(100, 100);
    }

    void updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option, const QModelIndex &index) const
    {
        Q_UNUSED(index);

        editor->setGeometry(option.rect.right() - 100, option.rect.height() + option.rect.top() - 70, 80, 50);
    }
};

#include "main.moc"

int main(int argc, char **argv)
{
    QApplication app(argc, argv);

    MyModel *myModel = new MyModel;
    MyDelegate *myDelegate = new MyDelegate;

    QVBoxLayout *layout = new QVBoxLayout;
    QWidget *myWidget = new QWidget;
    QListView *listView = new QListView;

    listView->setVerticalScrollMode(QListView::ScrollPerPixel);

    QTimer *timer = new QTimer;
    timer->setSingleShot(false);
    timer->setInterval(1000);

    timer->start();

    QObject::connect(myModel, SIGNAL(rowsInserted(const QModelIndex&,int,int)),
                     listView, SLOT(rowsInserted(const QModelIndex&,int,int)));

    QObject::connect(myModel, SIGNAL(rowsRemoved(const QModelIndex&,int,int)),
                     listView, SLOT(rowsAboutToBeRemoved(const QModelIndex&,int,int)));

    QObject::connect(myModel, SIGNAL(dataChanged(const QModelIndex&,const QModelIndex&)),
                     listView, SLOT(dataChanged(const QModelIndex&,const QModelIndex&)));

    QObject::connect(timer, SIGNAL(timeout()), myModel, SLOT(updateTime()));

    myWidget->setLayout(layout);
    listView->setModel(myModel);
    listView->setItemDelegate(myDelegate);
    layout->addWidget(listView);

    myWidget->show();

    for (int i = 0; i < 5; i++)
    {
        myModel->insertRow(i);
        myModel->setData(myModel->index(i, 0), QString("Click me %1").arg(QString::number(i)), Qt::DisplayRole);
        listView->openPersistentEditor(myModel->index(i, 0));
    }

    return app.exec();
}
