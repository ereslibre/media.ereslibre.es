/**
  * This file is part of the KDE project
  * Copyright (C) 2007 Rafael Fernández López <ereslibre@gmail.com>
  *
  * This library is free software; you can redistribute it and/or
  * modify it under the terms of the GNU Library General Public
  * License as published by the Free Software Foundation; either
  * version 2 of the License, or (at your option) any later version.
  *
  * This library is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  * Library General Public License for more details.
  *
  * You should have received a copy of the GNU Library General Public License
  * along with this library; see the file COPYING.LIB.  If not, write to
  * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  * Boston, MA 02110-1301, USA.
  */

#include "piechart.h"

#include <math.h>

#include <QSize>
#include <QPainter>
#include <QPaintEvent>

#include <kcolorscheme.h>

class PieChart::Private
{
public:
    Private(PieChart *q);
    ~Private();

    void drawKeys(QPainter *painter,  const QRect &paintRect) const;
    QSize sizeKeys(QPainter *painter) const;

    class PieChartSlice;
    class PieChartKeysElement;

    QList<PieChartSlice*> slices;
    bool showKeys;
    KeysPosition keysPosition;
    int keysPixelSeparator;
    int maxPenWidth;

    PieChart *q;
};


class PieChart::Private::PieChartSlice
{
public:
    PieChartSlice(const QString &sliceKey, int percent,  const QBrush &brush, const QPen &pen);
    ~PieChartSlice();

    QString sliceKey;
    int percent;
    QBrush brush;
    QPen pen;
};


PieChart::Private::PieChartSlice::PieChartSlice(const QString &sliceKey, int percent, const QBrush &brush, const QPen &pen)
    : sliceKey(sliceKey)
    , percent(percent)
    , brush(brush)
    , pen(pen)
{
}

PieChart::Private::PieChartSlice::~PieChartSlice()
{
}


PieChart::Private::Private(PieChart *q)
    : showKeys(true)
    , keysPosition(Right)
    , keysPixelSeparator(5)
    , maxPenWidth(0)
    , q(q)
{
}

PieChart::Private::~Private()
{
    qDeleteAll(slices);
    slices.clear();
}

void PieChart::Private::drawKeys(QPainter *painter, const QRect &paintRect) const
{
    QRect keysRect(paintRect);
    QSize size = sizeKeys(painter);

    if ((keysPosition == Left) ||
        (keysPosition == Right))
    {
        int currentX;

        if (keysPosition == Left)
        {
            keysRect.setRight(keysRect.left() + size.width());

            currentX = 0;
        }
        else
        {
            keysRect.setLeft(keysRect.right() - size.width());

            currentX = keysRect.right() - painter->fontMetrics().height() /* colored square */;
        }

        int currentY = ((float) paintRect.height() / 2) - ((float) size.height() / 2);
        foreach (PieChartSlice *slice, slices)
        {
            painter->save();
            painter->translate(currentX, currentY);
            painter->fillRect(QRect(0, 0, painter->fontMetrics().height(), painter->fontMetrics().height()), slice->brush);
            painter->restore();

            if (keysPosition == Left)
            {
                painter->drawText(QPoint(currentX + painter->fontMetrics().height() /* colored square */ + keysPixelSeparator, currentY + ((float) painter->fontMetrics().height() / 2) + ((float) painter->fontMetrics().height() / 4)), slice->sliceKey);
            }
            else
            {
                painter->drawText(QPoint(currentX - painter->fontMetrics().width(slice->sliceKey) - keysPixelSeparator, currentY + ((float) painter->fontMetrics().height() / 2) + ((float) painter->fontMetrics().height() / 4)), slice->sliceKey);
            }

            currentY += painter->fontMetrics().height() + keysPixelSeparator;
        }
    }
    else if ((keysPosition == Top) ||
             (keysPosition == Bottom))
    {
        int currentY;

        if (keysPosition == Top)
        {
            keysRect.setBottom(keysRect.top() + size.height());

            currentY = 0;
        }
        else
        {
            keysRect.setTop(keysRect.bottom() - size.height());

            currentY = keysRect.bottom() - painter->fontMetrics().height() /* colored square */;
        }

        int currentX = (q->layoutDirection() == Qt::LeftToRight) ? ((float) paintRect.width() / 2) - ((float) size.width() / 2)
                                                                 : ((float) paintRect.width() / 2) + ((float) size.width() / 2);
        foreach (PieChartSlice *slice, slices)
        {
            if (q->layoutDirection() == Qt::LeftToRight)
            {
                painter->save();
                painter->translate(currentX, currentY);
                painter->fillRect(QRect(0, 0, painter->fontMetrics().height(), painter->fontMetrics().height()), slice->brush);
                painter->restore();
                painter->drawText(QPoint(currentX + painter->fontMetrics().height() /* colored square */ + keysPixelSeparator, currentY + ((float) painter->fontMetrics().height() / 2) + ((float) painter->fontMetrics().height() / 4)), slice->sliceKey);

                currentX += painter->fontMetrics().width(slice->sliceKey) + keysPixelSeparator * 2 + painter->fontMetrics().height() /* colored square */;
            }
            else
            {
                painter->save();
                painter->translate(currentX, currentY);
                painter->fillRect(QRect(-painter->fontMetrics().height() /* colored square */, 0, painter->fontMetrics().height(), painter->fontMetrics().height()), slice->brush);
                painter->restore();
                painter->drawText(QPoint(currentX - painter->fontMetrics().height() /* colored square */ - keysPixelSeparator - painter->fontMetrics().width(slice->sliceKey), currentY + ((float) painter->fontMetrics().height() / 2) + ((float) painter->fontMetrics().height() / 4)), slice->sliceKey);

                currentX -= painter->fontMetrics().width(slice->sliceKey) + keysPixelSeparator * 2 + painter->fontMetrics().height() /* colored square */;
            }
        }
    }
}

QSize PieChart::Private::sizeKeys(QPainter *painter) const
{
    if ((keysPosition == Left) ||
        (keysPosition == Right))
    {
        int maxWidth = 0;

        foreach (PieChartSlice *slice, slices)
        {
            maxWidth = qMax(maxWidth, painter->fontMetrics().width(slice->sliceKey) + keysPixelSeparator + painter->fontMetrics().height() /* colored square */);
        }

        return QSize(maxWidth + keysPixelSeparator, slices.count() * painter->fontMetrics().height() + (slices.count() - 1) * keysPixelSeparator);
    }
    else
    {
        int width = 0;

        foreach (PieChartSlice *slice,  slices)
        {
            width += painter->fontMetrics().width(slice->sliceKey) + keysPixelSeparator * 2 + painter->fontMetrics().height() /* colored square */;
        }

        return QSize(width, painter->fontMetrics().height() + keysPixelSeparator);
    }
}

PieChart::PieChart(QWidget *parent)
    : QWidget(parent)
    , d(new Private(this))
{
    resize(600, 600);
}

PieChart::~PieChart()
{
    delete d;
}

void PieChart::addSlice(const QString &sliceKey, int percent, const QBrush &brush, const QPen &pen)
{
    QPen copyPen(pen);

    if (pen.width() > d->maxPenWidth)
    {
        d->maxPenWidth = pen.width();

        foreach (Private::PieChartSlice *slice, d->slices)
        {
            slice->pen.setWidth(d->maxPenWidth);
        }
    }
    else
    {
        copyPen.setWidth(d->maxPenWidth);
    }

    d->slices << new Private::PieChartSlice(sliceKey, percent, brush, copyPen);
}

bool PieChart::showKeys() const
{
    return d->showKeys;
}

void PieChart::setShowKeys(bool showKeys)
{
    d->showKeys = showKeys;

    update();
}

PieChart::KeysPosition PieChart::keysPosition() const
{
    return d->keysPosition;
}

void PieChart::setKeysPosition(PieChart::KeysPosition keysPosition)
{
    d->keysPosition = keysPosition;

    update();
}

void PieChart::paintEvent(QPaintEvent *event)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    QRect pieRect = event->rect();

    if (d->showKeys)
    {
        d->drawKeys(&p, pieRect);

        switch(d->keysPosition)
        {
            case Left:
                pieRect.setLeft(pieRect.left() + d->sizeKeys(&p).width());
                break;

            case Top:
                pieRect.setTop(pieRect.top() + d->sizeKeys(&p).height());
                break;

            case Right:
                pieRect.setRight(pieRect.right() - d->sizeKeys(&p).width());
                break;

            case Bottom:
                pieRect.setBottom(pieRect.bottom() - d->sizeKeys(&p).height());
                break;
        }
    }

    double start = 0;
    double totalPixels = M_PI * pieRect.width();
    foreach (Private::PieChartSlice *slice, d->slices)
    {
        QRectF copyPieRect(pieRect);
        double slicePercent = (slice->percent / 100.0) * 360;
        double oldSlicePercent = slicePercent;

        // We need to recalculate angle because of borders
        double localPixels = (slicePercent * totalPixels) / 360.0;
        double localPixelsMod = localPixels - (slice->pen.width());
        slicePercent = (slicePercent * localPixelsMod) / localPixels;

        if (!start)
        {
            start += ((abs(slicePercent - oldSlicePercent)) / 2.0) * 16;
        }

        // Resize the chart to fit on the widget placement
        copyPieRect.setLeft(copyPieRect.left() + d->maxPenWidth);
        copyPieRect.setRight(copyPieRect.right() - d->maxPenWidth);
        copyPieRect.setTop(copyPieRect.top() + d->maxPenWidth);
        copyPieRect.setBottom(copyPieRect.bottom() - d->maxPenWidth);

        // Draw the slice
        p.setBrush(slice->brush);
        p.setPen(slice->pen);
        p.drawPie(copyPieRect, start, slicePercent * 16);

        start += oldSlicePercent * 16;
    }
    //gradient
    QRadialGradient shadow(QPoint(pieRect.width()/2,pieRect.width()/2),pieRect.width()/2,QPoint(pieRect.width()/4,pieRect.width()/4));
    shadow.setColorAt(0,QColor(255,255,255,100));
    shadow.setColorAt(1,QColor(0,0,0,155));
    p.setBrush(shadow);
    p.setPen(Qt::NoPen);
    p.drawEllipse(pieRect);
}
